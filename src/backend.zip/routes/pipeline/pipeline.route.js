import express from "express";
import pipelineController from "../../controllers/pipeline/pipeline.controller.js";

const pipelineRoute = express.Router();

// Stats & Global Management (Specific routes first)
pipelineRoute.get("/pipeline/stats/platform-wallet", pipelineController.getPlatformWalletStats);
pipelineRoute.get("/pipeline/stats/platform-wallet/transactions", pipelineController.getPlatformWalletTransactions);
pipelineRoute.get("/pipeline/logistics/all", pipelineController.getAllLogistics);
pipelineRoute.post("/pipeline/logistics/update-status", pipelineController.updateLogisticsStatus);
pipelineRoute.get("/pipeline/warehouse/inventory", pipelineController.getWarehouseInventory);
pipelineRoute.post("/pipeline/warehouse/inventory", pipelineController.addWarehouseStock);
pipelineRoute.delete("/pipeline/warehouse/inventory/:id", pipelineController.removeWarehouseStock);
pipelineRoute.get("/pipeline/distributors", pipelineController.getDistributors);

// Pre-Harvest
pipelineRoute.post("/pipeline/preharvest", pipelineController.createPreHarvestListing);
pipelineRoute.get("/pipeline/preharvest/cluster/:id", pipelineController.getClusterPreHarvestListings);
pipelineRoute.get("/pipeline/preharvest/opportunities", pipelineController.getAllPreHarvestOpportunities);

// Forward Contracts
pipelineRoute.post("/pipeline/forward-contracts", pipelineController.createForwardContract);
pipelineRoute.get("/pipeline/forward-contracts/buyer", pipelineController.getBuyerForwardContracts);
pipelineRoute.get("/pipeline/forward-contracts/sales", pipelineController.getSalesForwardContracts);

// Farmer Profiles
pipelineRoute.post("/pipeline/farmer-profile", pipelineController.createFarmerProfile);
pipelineRoute.get("/pipeline/farmer-profile/me", pipelineController.getMyFarmerProfile);
pipelineRoute.patch("/pipeline/farmer-profile/enroll", pipelineController.enrollInProgram);
pipelineRoute.get("/pipeline/farmers", pipelineController.getAllFarmers);

// Wallets
pipelineRoute.get("/pipeline/wallet", pipelineController.getMyWallet);
pipelineRoute.post("/pipeline/wallet/transfer", pipelineController.transferFunds);
pipelineRoute.post("/pipeline/wallet/transfer/ecosystem", pipelineController.transferToEcosystem);
pipelineRoute.post("/pipeline/wallet/fund/initialize", pipelineController.initializeWalletFunding);
pipelineRoute.get("/pipeline/wallet/fund/verify", pipelineController.verifyWalletFunding);

// Clusters
pipelineRoute.post("/pipeline/clusters", pipelineController.createCluster);
pipelineRoute.get("/pipeline/clusters", pipelineController.getClusters);
pipelineRoute.get("/pipeline/clusters/mine", pipelineController.getMyCluster);
pipelineRoute.get("/pipeline/clusters/nearby", pipelineController.getNearbyClusters);
pipelineRoute.get("/pipeline/clusters/eligible-farmers", pipelineController.getEligibleFarmers);
pipelineRoute.post("/pipeline/clusters/assign", pipelineController.assignFarmer);
pipelineRoute.get("/pipeline/clusters/:id/members", pipelineController.getClusterMembers);
pipelineRoute.delete("/pipeline/clusters/:id/members/:farmerId", pipelineController.removeFarmer);

// Cluster Chats & Training
pipelineRoute.get("/pipeline/clusters/:id/chats", pipelineController.getClusterChats);
pipelineRoute.post("/pipeline/clusters/:id/chats", pipelineController.sendClusterChat);
pipelineRoute.post("/pipeline/clusters/:id/training", pipelineController.scheduleTraining);
pipelineRoute.get("/pipeline/clusters/:id/training", pipelineController.getClusterLiveTrainings);
pipelineRoute.post("/pipeline/clusters/training/:trainingId/start", pipelineController.startClusterTraining);
pipelineRoute.post("/pipeline/clusters/training/:trainingId/join", pipelineController.joinClusterTraining);
pipelineRoute.patch("/pipeline/clusters/training/:trainingId/status", pipelineController.updateTrainingStatus);

// Training
pipelineRoute.get("/pipeline/training", pipelineController.getTrainingProgress);
pipelineRoute.post("/pipeline/training/update", pipelineController.updateTraining);

// Input Requests
pipelineRoute.post("/pipeline/inputs/request", pipelineController.createInputRequest);
pipelineRoute.get("/pipeline/inputs/mine", pipelineController.getMyInputRequests);
pipelineRoute.get("/pipeline/inputs/pending", pipelineController.getPendingInputs);
pipelineRoute.get("/pipeline/inputs/all", pipelineController.getAllInputs);
pipelineRoute.patch("/pipeline/inputs/:id/approve-funds", pipelineController.approveFunds);
pipelineRoute.patch("/pipeline/inputs/:id/submit-items", pipelineController.submitInputItems);
pipelineRoute.patch("/pipeline/inputs/:id/approve-items", pipelineController.approveItems);
pipelineRoute.get("/pipeline/inputs/distributor", pipelineController.getDistributorInputs);
pipelineRoute.patch("/pipeline/inputs/:id/status", pipelineController.updateInputStatus);
pipelineRoute.patch("/pipeline/inputs/:id/confirm-delivery", pipelineController.confirmDelivery);

// Planting
pipelineRoute.post("/pipeline/planting", pipelineController.createPlanting);
pipelineRoute.get("/pipeline/planting/mine", pipelineController.getMyPlanting);

// Field Verifications
pipelineRoute.post("/pipeline/verifications", pipelineController.createVerification);
pipelineRoute.get("/pipeline/verifications/cluster/:id", pipelineController.getClusterVerifications);

// Supervision (cluster routes first to avoid :farmerId matching "cluster")
pipelineRoute.get("/pipeline/supervision/cluster/:clusterId", pipelineController.getClusterSupervision);
pipelineRoute.post("/pipeline/supervision/cluster/update", pipelineController.updateClusterSupervision);
pipelineRoute.get("/pipeline/supervision/:farmerId", pipelineController.getSupervision);
pipelineRoute.post("/pipeline/supervision/update", pipelineController.updateSupervision);

// Harvest
pipelineRoute.post("/pipeline/harvest", pipelineController.createHarvest);

// Logistics
pipelineRoute.post("/pipeline/logistics", pipelineController.createLogistics);
pipelineRoute.get("/pipeline/logistics/cluster/:id", pipelineController.getClusterLogistics);

// Buyer Matches
pipelineRoute.post("/pipeline/buyer-matches", pipelineController.createBuyerMatch);
pipelineRoute.get("/pipeline/buyer-matches", pipelineController.getBuyerMatches);

// Sales
pipelineRoute.post("/pipeline/sales", pipelineController.createSale);
pipelineRoute.get("/pipeline/sales/cluster/:id", pipelineController.getClusterSales);

// Repayments
pipelineRoute.post("/pipeline/repayments", pipelineController.createRepayment);
pipelineRoute.patch("/pipeline/repayments/:id", pipelineController.processRepayment);

// Dashboard Stats
pipelineRoute.get("/pipeline/stats", pipelineController.getStats);
pipelineRoute.get("/pipeline/stats/sales", pipelineController.getSalesDashboardStats);
pipelineRoute.get("/pipeline/stats/intelligence", pipelineController.getIntelligenceDashboardStats);
pipelineRoute.get("/pipeline/distributor/stats", pipelineController.getDistributorStats);

// Ecosystem Buyer Orders
pipelineRoute.post("/pipeline/buyer-orders", pipelineController.createEcosystemOrder);
pipelineRoute.get("/pipeline/buyer-orders/mine", pipelineController.getEcosystemOrders);
pipelineRoute.get("/pipeline/buyer-orders/all", pipelineController.getAllEcosystemOrders);
pipelineRoute.post("/pipeline/buyer-orders/:id/payment/initialize", pipelineController.initializeEcosystemOrderPayment);
pipelineRoute.post("/pipeline/buyer-orders/payment/verify", pipelineController.verifyEcosystemOrderPayment);
pipelineRoute.get("/pipeline/buyer-orders/payment/verify", pipelineController.verifyEcosystemOrderPayment);
pipelineRoute.patch("/pipeline/buyer-orders/:id/payment/finance-confirm", pipelineController.confirmEcosystemOrderPayment);
pipelineRoute.patch("/pipeline/buyer-orders/:id/status", pipelineController.updateOrderStatus);
pipelineRoute.post("/pipeline/buyer-orders/escrow-pay", pipelineController.processEscrowPayment);
pipelineRoute.post("/pipeline/buyer-orders/assign-distributor", pipelineController.assignOrderDistributor);
pipelineRoute.get("/pipeline/distributor/orders", pipelineController.getDistributorOrders);
pipelineRoute.post("/pipeline/distributor/mark-delivered", pipelineController.markOrderAsDelivered);

export default pipelineRoute;
