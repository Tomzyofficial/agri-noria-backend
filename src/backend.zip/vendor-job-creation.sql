CREATE TABLE jobs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    vendor_id UUID NOT NULL REFERENCES vendors(id) ON DELETE CASCADE,
    title VARCHAR(255) NOT NULL,
    category VARCHAR(100) NOT NULL,
    custom_category VARCHAR(100),
    employment_type VARCHAR(50) NOT NULL,
    openings INTEGER DEFAULT 1,
    state VARCHAR(100) NOT NULL,
    city VARCHAR(100) NOT NULL,
    country VARCHAR(100) NOT NULL,
    location_type VARCHAR(50) DEFAULT 'on_site',
   application_deadline TIMESTAMPTZ,
    salary_type VARCHAR(50),
    salary_min NUMERIC(12,2),
    salary_max NUMERIC(12,2),
    experience_level VARCHAR(100),
    education_level VARCHAR(100),
    description TEXT NOT NULL,
    responsibilities TEXT,
    requirements TEXT,
    benefits TEXT,
    applicants_count INTEGER DEFAULT 0,
    status VARCHAR(50) DEFAULT 'active',
    expires_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_job_vendor_id ON jobs(vendor_id);

CREATE TABLE job_applications (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    job_id UUID NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
    full_name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    phone VARCHAR(50) NOT NULL,
    state VARCHAR(100) NOT NULL,
    city VARCHAR(100) NOT NULL,
    country VARCHAR(100) NOT NULL,
    experience_level VARCHAR(100) DEFAULT 'N/A',
    education_level VARCHAR(100) DEFAULT 'N/A',
    cv_file TEXT DEFAULT 'N/A',
    cover_letter TEXT DEFAULT 'N/A',
    linkedin_url TEXT DEFAULT 'N/A',
    status VARCHAR(50) DEFAULT 'new',
    reviewed_at TIMESTAMPTZ,
    shortlisted_at TIMESTAMPTZ,
    rejected_at TIMESTAMPTZ,
    hired_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(job_id, email)
);

CREATE INDEX IF NOT EXISTS idx_job_applications_job_id ON job_applications(job_id);


